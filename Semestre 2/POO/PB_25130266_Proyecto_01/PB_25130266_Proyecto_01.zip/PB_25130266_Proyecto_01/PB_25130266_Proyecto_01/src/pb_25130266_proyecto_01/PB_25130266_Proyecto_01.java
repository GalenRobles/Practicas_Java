/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pb_25130266_proyecto_01;

/**
 *
 * @author trcuser
 */
public class PB_25130266_Proyecto_01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Circuito X = new Circuito(480.0,6.0,5.0,"x");
        System.out.println(X);
        System.out.println(X.CalcularRm());
        
    }
    
}
